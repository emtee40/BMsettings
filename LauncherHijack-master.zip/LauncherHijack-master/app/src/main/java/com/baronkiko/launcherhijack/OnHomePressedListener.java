package com.baronkiko.launcherhijack;

public interface OnHomePressedListener {
    public void onHomePressed();

    public void onRecentAppPressed();
}